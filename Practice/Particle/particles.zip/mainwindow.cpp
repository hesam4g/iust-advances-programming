#include "mainwindow.h"
#include <QGraphicsLineItem>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{

    scene = new AScene();
    view = new QGraphicsView(scene);

    setCentralWidget(view);
}

MainWindow::~MainWindow()
{

}
